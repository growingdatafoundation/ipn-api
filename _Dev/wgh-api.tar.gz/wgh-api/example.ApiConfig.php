<?php
/**
 * Store sensible config data here and require this file in root file
 */
 
class ApiConfig{
    
    /**
     * @var array Flickr API keys
     */
    public static $Flickr = array(
        'key'       => 'ea1dba5cdcb32b9ef5f27746167a2008',
        'secret'    => '74ee564ed2b6c2d4',
        'name'      => 'GovHackAustralia2014',
    );

}
